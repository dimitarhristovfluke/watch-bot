import { DashboardCheck } from "./src/common/api/dashboard";

setInterval(DashboardCheck, 60000);
