const config = {
  dateTimeFormat: "MM/DD/YYYY HH:mm:ss",
  serverZoneOffset: 60
};

export default config;
